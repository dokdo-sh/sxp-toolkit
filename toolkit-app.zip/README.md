# Toolkit

<p align="center">
    <img src="./banner.jpg?sanitize=true" />
</p>

Toolkit


Requirements:
- nodejs
- pm2
- yarn


```
yarn install
node toolkit.js
```

for live editing use "pm2 start toolkit.js --watch"

```
pm2 start toolkit.js --watch
```
App visible at "https://localhost:8500"
